%{
MAIN SCRIPT
-------------------------------------------------------------------------
Paper:   Estimation of Clinical Trial Success Rates and Related Parameters
Journal: Biostatistics
Authors: CH Wong, KW Siah, AW Lo
-------------------------------------------------------------------------

This code illustrates the computation of the path-by-path POS from trial information. 

We use sample trial information stored in 'Sample_data.csv' and 'Approval_data.csv'.
  - 'Sample_data.csv' encodes the trial information: 
    [TrialID, DrugID, DiseaseID, TherapeuticArea, TrialPhaseID, EndDate]
  - 'Approval_data.csv' encodes the approval information
    [DrugID, DiseaseID, IsApproved]

Description of data:
  - TrialID: Identifier for a trial
  - DrugID: Identifier for a drug
  - DiseaseID: Identifier for a disease
  - TherapeuticArea: Identifier for a therapeutic area
  - TrialPhaseID: 1,2,3,6,7 for Phase I, II, III, I/II, II/III respectively
  - EndDate: End date for the trial
  - IsApproved: '1' if the drug and indication has been approved. '0' otherwise

Dependent files:
1. computeGrp.m
2. isApprovedForIndication.m
%}

%% Load Data
fprintf('Loading data... ')

data_filename = 'Sample_data.csv';
appv_filename = 'Approval_data.csv';

trial_data = csvread(data_filename);        % Trial data
appv_data = csvread(appv_filename);         % Approval data

fprintf('Done\n')

%% Compute the number of failures and successes
uniqueTheraGrp=unique(trial_data(:,4));     % Get unique therapeutic groups
results = zeros(length(uniqueTheraGrp), 11);% Preallocate result table

for i=1:length(uniqueTheraGrp)
    % For every therapeutic group...
    indGrpId = uniqueTheraGrp(i);
    ... we compute the POSs
    results(i,:) = computeGrp(indGrpId, trial_data, appv_data);
end
results = [results; sum(results,1)];
fprintf('Computing done\n')

%% Compute the POSs
Total1 = sum(results(:,2:3),2);
POS1_2 = results(:,2)./Total1;

Total2 = sum(results(:,4:5),2);
POS2_3 = results(:,4)./Total2;

Total3 = sum(results(:,6:7),2);
POS3_A = results(:,6)./Total3;

POS_overall  = results(:,6)./(results(:,3)+results(:,5)+results(:,6)+results(:,7));

%% Save to excel
fprintf('Saving to Excel Sheet... ')

formatted_table = [results(:,1), Total1, POS1_2, Total2, POS2_3, Total3, POS3_A, POS_overall];
xlswrite('POS_Results.xlsx',{'Indication Group', 'Phase 1', '', 'Phase 2', '', 'Phase 3', '', 'Overall'}, 'A1:H1');
xlswrite('POS_Results.xlsx',{'', 'Total Paths', 'POS1_2', 'Total Paths', 'POS2_3', 'Total Paths', 'POS3_App','POS'}, 'A2:H2');
xlswrite('POS_Results.xlsx', formatted_table, 'A3:H12');
xlswrite('POS_Results.xlsx', {'Total'}, 'A12:A12');

fprintf('Done\n')
