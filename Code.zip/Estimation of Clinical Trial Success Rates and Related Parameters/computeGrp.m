function result = computeGrp(indGrpId, trial_data, appv_data)
%{
-------------------------------------------------------------------------
Paper:   Estimation of Clinical Trial Success Rates and Related Parameters
Journal: Biostatistics
Authors: CH Wong, KW Siah, AW Lo
-------------------------------------------------------------------------

This function computes the number of successes and failures for a specific
therapeutic group.

Dependent files:
1. isApprovedForIndication.m
%}

fprintf('Computing POS for indication group %d\n',indGrpId)

cutoffEndDate = 165764; % What is snapshot date of the dataset?

% Initialize
phaseI_succ =0;
phaseI_fail =0;
phaseI_inProg = 0;
phaseII_succ =0;
phaseII_fail =0;
phaseII_inProg = 0;
phaseIII_succ =0;
phaseIII_fail =0;
phaseIII_inProg = 0;
num_drugDevProj = 0;

% Filter by therapeutic groups
idx = trial_data(:,4)==indGrpId;
trial_data=trial_data(idx,:);

% Sort rows by drug
[~,I]=sort(trial_data(:,2));
trial_data = trial_data(I,:);

% Get unique drugs
uniqueDrugs = unique(trial_data(:,2));

% For every drug, ....
for drug = uniqueDrugs'
    drug_idx = trial_data(:,2) == drug;
    subTable = trial_data(drug_idx,:);
    
    % ... find the unique indications
    uniqueInds = unique(subTable(:,3));
    
    % Then, for every unique indication, ...
    for ind = uniqueInds'
        num_drugDevProj = num_drugDevProj+1; % increment count for number of development projects
        
        % Create yet another sublist (cos memory is cheap and i am lazy to keep track)
        ind_idx = subTable(:,3) == ind;
        phases = subTable(ind_idx,5);
        endDates = subTable(ind_idx,6);
        
        % Indicators for phases
        isPhase3 = phases ==3 | phases ==7;
        isPhase2 = phases ==2 | phases ==6;
        isPhase1 = phases ==1;
        
        % Analyze
        % The rule here is,
        % - if Phase 4 is observed, then Phases 1~3
        % are deemed to have passed
        % - If Phase 3 is observed, then Phases 1~2 are considered to
        % have passed
        % - If Phase 2 is observed, then Phase 1 is deemed to have
        % passed on to Phase 2. But Phase 2 is deemed to have
        % failed.
        
        % Get drug development status
        hasBeenApproved = isApprovedForIndication(appv_data, drug, ind); % function returns '1' if the drug has been approved and for the indication and '0' otherwise
        
        if (hasBeenApproved==1) % The drug was launched, registered or withdrawn
            phaseI_succ = phaseI_succ +1;
            phaseII_succ = phaseII_succ +1;
            phaseIII_succ = phaseIII_succ+1;
        else
            if sum(isPhase3)>0  % The drug was not launched but there is a Phase III
                phaseI_succ = phaseI_succ +1;
                phaseII_succ = phaseII_succ +1;
                
                % The drug not being approved doesn't mean that it has
                % failed to be approved. It may mean that it is now in
                % Phase III and is preparing for NDA. We give drug
                % development programs allowance for this possibility. In
                % this case, we count the Phase III as 'in-progress' 
                % instead of a failture if the last known Phase III trial 
                % ended in this grace period
                phaseIII_end = max(endDates(isPhase3));
                if (phaseIII_end + 30*30 < cutoffEndDate) % 30 months allowance for Phase III to Approval
                    phaseIII_fail = phaseIII_fail+1;
                else
                    phaseIII_inProg = phaseIII_inProg + 1;
                end
            else
                if sum(isPhase2)>0 % No Phase III observed but we observe P2
                    phaseI_succ = phaseI_succ +1;
                    
                    % Again, we give time allowance for transitions
                    phaseII_end = max(endDates(isPhase2));
                    if (phaseII_end + 18*30 < cutoffEndDate) % 18 months allowance for Phase II to Phase III
                        phaseII_fail = phaseII_fail+1;
                    else
                        phaseII_inProg = phaseII_inProg+1;
                    end
                else
                    if sum(isPhase1)>0 % No Phase 2 or Phase 3 or approval observed, but we observe Phase I
                        phaseI_end = max(endDates(isPhase1));
                        
                        % Again, we give time allowance for transitions
                        if (phaseI_end + 12*30 < cutoffEndDate) % 12 months allowance for Phase I to Phase II
                            phaseI_fail = phaseI_fail+1;
                        else
                            phaseI_inProg=phaseI_inProg+1;
                            num_drugDevProj = num_drugDevProj-1;
                        end
                    end
                end
            end
        end
    end
end

result = [indGrpId, ...
    phaseI_succ, phaseI_fail, ...
    phaseII_succ, phaseII_fail, ...
    phaseIII_succ, phaseIII_fail, ...
    phaseI_inProg, phaseII_inProg, phaseIII_inProg, ...
    num_drugDevProj];