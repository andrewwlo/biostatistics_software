Paper:   Estimation of Clinical Trial Success Rates and Related Parameters
Journal: Biostatistics
Authors: CH Wong, KW Siah, AW Lo

----------------------------------------------------------------------------
Contents
----------------------------------------------------------------------------
* Sample data files (Data description at the end of this document)
1. 'Sample_data.csv'    : Sample trial information
2. 'Approval_data.csv'  : Sample approval information

* MATLAB files
1. MainScript             : Wrapper script
2. isApprovedForIndication: Dependent script used to check for approvals
3. computeGrp             : Dependent script that does most of the computations

----------------------------------------------------------------------------
Instructions
----------------------------------------------------------------------------
1. Run 'MainScript.m' on MATLAB to generate POSs. The results will be saved 
   into an MS Excel Sheet, 'POS_Results.xlsx'.

----------------------------------------------------------------------------
Description of sample data
----------------------------------------------------------------------------
  - TrialID: Identifier for a trial
  - DrugID: Identifier for a drug
  - DiseaseID: Identifier for a disease
  - TherapeuticArea: Identifier for a therapeutic area
  - TrialPhaseID: 1,2,3,6,7 for Phase I, II, III, I/II, II/III respectively
  - EndDate: End date for the trial
  - IsApproved: '1' if the drug and indication has been approved. '0' otherwise
%}