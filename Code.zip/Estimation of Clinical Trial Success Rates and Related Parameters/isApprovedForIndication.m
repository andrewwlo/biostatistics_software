function hasBeenApproved = isApprovedForIndication(appv_data, drug, ind)
%{
-------------------------------------------------------------------------
Paper:   Estimation of Clinical Trial Success Rates and Related Parameters
Journal: Biostatistics
Authors: CH Wong, KW Siah, AW Lo
-------------------------------------------------------------------------

This function checks and returns '1' if the drug and indication has been
approved. Returns '0' otherwise.

%}
hasBeenApproved = appv_data(appv_data(:,1)==drug & appv_data(:,2)==ind,3);
end